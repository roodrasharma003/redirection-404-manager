<?php
if (!defined('WP_UNINSTALL_PLUGIN')) exit;
global $wpdb;
$wpdb->query("DROP TABLE IF EXISTS {$wpdb->prefix}roodrar404_rules");
$wpdb->query("DROP TABLE IF EXISTS {$wpdb->prefix}roodrar404_logs");
