<?php
/**
 * Plugin Name: Roodra Redirection & 404 Manager
 * Description: Manage URL redirects and review recent 404 errors.
 * Plugin URI: https://github.com/roodrasharma003/roodrasharma-redirection-404-manager
 * Version: 1.0.0
 * Requires at least: 6.2
 * Tested up to: 7.1
 * Requires PHP: 7.4
 * Author: roodrasharma003
 * Author URI: https://roodrasharma003.github.io/
 * License: GPL-2.0-or-later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: roodrasharma-redirection-404-manager
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

final class Roodra_Redirect404_Manager {

    const VERSION = '1.0.0';
    const CACHE_GROUP = 'roodrar404';

    /**
     * Minimum WordPress version required by this plugin.
     *
     * The %i placeholder used by every prepared query below was introduced in
     * WordPress 6.2 (wpdb::prepare() identifier escaping). Running on an older
     * version would leave %i unsubstituted and break the queries, so the plugin
     * header declares "Requires at least: 6.2" accordingly.
     */
    const MIN_WP_VERSION = '6.2';

    private static function table( $name ) {
        global $wpdb;
        return $wpdb->prefix . 'roodrar404_' . $name;
    }

    /** Create/update custom tables on plugin activation only. */
    public static function activate() {
        global $wpdb;

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';

        $charset = $wpdb->get_charset_collate();
        $rules   = self::table( 'rules' );
        $logs    = self::table( 'logs' );

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.SchemaChange -- Custom plugin tables are managed on activation using dbDelta().
        dbDelta(
            "CREATE TABLE $rules (
                id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
                source varchar(2048) NOT NULL,
                source_hash char(64) NOT NULL,
                target text NOT NULL,
                status_code smallint unsigned NOT NULL DEFAULT 301,
                enabled tinyint(1) NOT NULL DEFAULT 1,
                hits bigint(20) unsigned NOT NULL DEFAULT 0,
                last_hit datetime DEFAULT NULL,
                PRIMARY KEY  (id),
                UNIQUE KEY source_hash (source_hash)
            ) $charset;"
        );

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.SchemaChange -- Custom plugin tables are managed on activation using dbDelta().
        dbDelta(
            "CREATE TABLE $logs (
                id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
                path varchar(2048) NOT NULL,
                path_hash char(64) NOT NULL,
                hits bigint(20) unsigned NOT NULL DEFAULT 1,
                last_seen datetime NOT NULL,
                PRIMARY KEY  (id),
                UNIQUE KEY path_hash (path_hash),
                KEY last_seen (last_seen)
            ) $charset;"
        );

        if ( false === get_option( 'roodrar404_cache_version', false ) ) {
            add_option( 'roodrar404_cache_version', 1, '', false );
        }
    }

    private static function cache_version() {
        return (int) get_option( 'roodrar404_cache_version', 1 );
    }

    /** Invalidate redirect lookup cache after redirect rules change. */
    private static function clear_rule_cache() {
        update_option(
            'roodrar404_cache_version',
            self::cache_version() + 1,
            false
        );
    }

    /** Return a cached redirect rule for an exact source path. */
    private static function get_rule( $path ) {
        global $wpdb;

        $table       = self::table( 'rules' );
        $cache_key   = 'rule_' . self::cache_version() . '_' . hash( 'sha256', $path );
        $cache_group = self::CACHE_GROUP;

        $rule = wp_cache_get( $cache_key, $cache_group );
        if ( false !== $rule ) {
            return $rule;
        }

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery -- Custom-table lookup is cached using the WordPress object cache.
        $rule = $wpdb->get_row(
            $wpdb->prepare(
                'SELECT * FROM %i WHERE source_hash = %s AND enabled = 1 LIMIT 1',
                $table,
                hash( 'sha256', $path )
            )
        );

        wp_cache_set( $cache_key, $rule, $cache_group, HOUR_IN_SECONDS );
        return $rule;
    }

    private static function normalize_path( $path ) {
        $path = trim( (string) $path );

        if (
            '' === $path ||
            '/' !== $path[0] ||
            '//' === substr( $path, 0, 2 ) ||
            false !== strpos( $path, '\\' ) ||
            preg_match( '/[\x00-\x20\x7f?#]/', $path )
        ) {
            return false;
        }

        if ( strlen( $path ) > 2048 ) {
            return false;
        }

        return $path;
    }

    private static function request_path() {
        // Preserve percent-encoded paths; normalize_path() validates the extracted path.
        // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Exact encoded path bytes are validated by normalize_path().
        $uri  = isset( $_SERVER['REQUEST_URI'] ) ? wp_unslash( $_SERVER['REQUEST_URI'] ) : '/';
        $path = explode( '?', $uri, 2 )[0];

        return self::normalize_path( $path );
    }

    /** Validate root-relative paths or absolute HTTP(S) URLs. */
    private static function target_valid( $target ) {
        if ( '' === $target || preg_match( '/[\x00-\x20\x7f\\\\]/', $target ) ) {
            return false;
        }

        if ( '/' === $target[0] ) {
            return '//' !== substr( $target, 0, 2 );
        }

        $url = wp_parse_url( $target );

        return is_array( $url ) &&
            ! empty( $url['host'] ) &&
            ! empty( $url['scheme'] ) &&
            in_array( strtolower( $url['scheme'] ), array( 'http', 'https' ), true ) &&
            empty( $url['user'] ) &&
            empty( $url['pass'] );
    }

    public static function redirect() {
        if (
            is_admin() ||
            ( defined( 'DOING_CRON' ) && DOING_CRON ) ||
            ( defined( 'REST_REQUEST' ) && REST_REQUEST )
        ) {
            return;
        }

        $path = self::request_path();
        if ( ! $path ) {
            return;
        }

        $rule = self::get_rule( $path );
        if ( ! $rule || $rule->source !== $path || ! self::target_valid( $rule->target ) ) {
            return;
        }

        // Avoid an obvious redirect loop on the current host and path.
        $destination = wp_parse_url( $rule->target );
        $home        = wp_parse_url( home_url( '/' ) );

        if (
            is_array( $destination ) &&
            ( $destination['path'] ?? '/' ) === $path &&
            ( empty( $destination['host'] ) || strcasecmp( $destination['host'], $home['host'] ?? '' ) === 0 )
        ) {
            return;
        }

        global $wpdb;
        $table = self::table( 'rules' );

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Atomic hit counter update in the custom redirect table.
        $wpdb->query(
            $wpdb->prepare(
                'UPDATE %i SET hits = hits + 1, last_hit = %s WHERE id = %d',
                $table,
                current_time( 'mysql', true ),
                $rule->id
            )
        );

        nocache_headers();

        $target = esc_url_raw( $rule->target );
        if ( ! empty( $target ) && self::target_valid( $target ) ) {
            // External HTTP(S) destinations are an intended feature; target_valid() restricts the scheme and URL structure.
            // phpcs:ignore WordPress.Security.SafeRedirect.wp_redirect_wp_redirect -- Admin-configured external redirects are supported and validated above.
            wp_redirect(
                $target,
                (int) $rule->status_code,
                'Roodra Redirection & 404 Manager'
            );
            exit;
        }
    }

    public static function log_404() {
        if ( ! is_404() || is_admin() || ( defined( 'REST_REQUEST' ) && REST_REQUEST ) ) {
            return;
        }

        $path = self::request_path();
        if ( ! $path ) {
            return;
        }

        global $wpdb;
        $table = self::table( 'logs' );

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Atomic upsert into the custom 404 log table.
        $wpdb->query(
            $wpdb->prepare(
                'INSERT INTO %i (path, path_hash, hits, last_seen) VALUES (%s, %s, 1, %s) ON DUPLICATE KEY UPDATE hits = hits + 1, last_seen = VALUES(last_seen)',
                $table,
                $path,
                hash( 'sha256', $path ),
                current_time( 'mysql', true )
            )
        );

        // Bound storage to the 1,000 most recently seen unique paths.
        if ( 1 === wp_rand( 1, 100 ) ) {
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Periodic cleanup of the custom 404 log table.
            $wpdb->query(
                $wpdb->prepare(
                    'DELETE FROM %i WHERE id NOT IN (SELECT id FROM (SELECT id FROM %i ORDER BY last_seen DESC, id DESC LIMIT 1000) AS recent)',
                    $table,
                    $table
                )
            );
        }
    }

    public static function menu() {
        add_management_page(
            'Roodra Redirection & 404 Manager',
            'Redirection & 404',
            'manage_options',
            'roodrar404-manager',
            array( __CLASS__, 'page' )
        );
    }

    private static function url( $args = array() ) {
        return add_query_arg(
            array_merge( array( 'page' => 'roodrar404-manager' ), $args ),
            admin_url( 'tools.php' )
        );
    }

    private static function finish( $notice ) {
        wp_safe_redirect( self::url( array( 'notice' => $notice ) ) );
        exit;
    }

    public static function actions() {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( esc_html__( 'You are not allowed to do this.', 'roodrasharma-redirection-404-manager' ) );
        }

        check_admin_referer( 'roodrar404_action' );

        global $wpdb;
        $action = isset( $_POST['roodrar404_action'] ) ? sanitize_key( wp_unslash( $_POST['roodrar404_action'] ) ) : '';
        $id     = isset( $_POST['id'] ) ? absint( $_POST['id'] ) : 0;
        $rules  = self::table( 'rules' );
        $logs   = self::table( 'logs' );

        if ( 'save' === $action ) {
            // Exact URL bytes are validated by normalize_path(); sanitizing could alter encoded paths.
            // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Exact path bytes are validated below.
            $source = self::normalize_path( isset( $_POST['source'] ) ? wp_unslash( $_POST['source'] ) : '' );

            // target_valid() strictly validates the destination without altering URL bytes.
            // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Destination is validated by target_valid().
            $target = trim( isset( $_POST['target'] ) ? wp_unslash( $_POST['target'] ) : '' );

            $status = isset( $_POST['status_code'] ) ? absint( $_POST['status_code'] ) : 301;

            if (
                ! $source ||
                ! self::target_valid( $target ) ||
                strlen( $target ) > 2048 ||
                ! in_array( $status, array( 301, 302, 307, 308 ), true )
            ) {
                self::finish( 'invalid' );
            }

            $data = array(
                'source'      => $source,
                'source_hash' => hash( 'sha256', $source ),
                'target'      => $target,
                'status_code' => $status,
                'enabled'     => isset( $_POST['enabled'] ) ? 1 : 0,
            );

            if ( $id ) {
                // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- WordPress wpdb API updates the custom plugin table.
                $result = $wpdb->update( $rules, $data, array( 'id' => $id ) );
            } else {
                // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- WordPress wpdb API inserts into the custom plugin table.
                $result = $wpdb->insert( $rules, $data );
            }

            if ( false !== $result ) {
                self::clear_rule_cache();
            }

            self::finish( false === $result ? 'error' : 'saved' );
        }

        if ( 'delete_rule' === $action && $id ) {
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- WordPress wpdb API deletes from the custom plugin table.
            $result = $wpdb->delete( $rules, array( 'id' => $id ), array( '%d' ) );

            if ( false !== $result ) {
                self::clear_rule_cache();
            }

            self::finish( false === $result ? 'error' : 'deleted' );
        }

        if ( 'delete_log' === $action && $id ) {
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- WordPress wpdb API deletes from the custom log table.
            $result = $wpdb->delete( $logs, array( 'id' => $id ), array( '%d' ) );
            self::finish( false === $result ? 'error' : 'deleted' );
        }

        if ( 'clear_logs' === $action ) {
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Clearing the custom log table is an intentional admin action.
            $result = $wpdb->query( $wpdb->prepare( 'DELETE FROM %i', $logs ) );
            self::finish( false === $result ? 'error' : 'cleared' );
        }

        self::finish( 'error' );
    }

    private static function form_start( $action, $id = 0 ) {
        echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
        wp_nonce_field( 'roodrar404_action' );
        echo '<input type="hidden" name="action" value="roodrar404_action">';
        echo '<input type="hidden" name="roodrar404_action" value="' . esc_attr( $action ) . '">';
        echo '<input type="hidden" name="id" value="' . esc_attr( $id ) . '">';
    }

    public static function page() {
        if ( ! current_user_can( 'manage_options' ) ) {
            return;
        }

        global $wpdb;
        $rules_table = self::table( 'rules' );
        $logs_table  = self::table( 'logs' );

        // GET parameters select/prefill the admin view; all writes require a nonce.
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only admin view parameter.
        $edit_id = isset( $_GET['edit'] ) ? absint( $_GET['edit'] ) : 0;

        if ( $edit_id ) {
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Read-only single admin record; caching is not useful for this transient edit view.
            $edit = $wpdb->get_row(
                $wpdb->prepare(
                    'SELECT * FROM %i WHERE id = %d',
                    $rules_table,
                    $edit_id
                )
            );
        } else {
            $edit = null;
        }

        // Preserve encoded paths; normalize_path validates the input.
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended, WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Read-only prefill value validated by normalize_path().
        $prefill = isset( $_GET['source'] ) ? self::normalize_path( wp_unslash( $_GET['source'] ) ) : '';

        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only pagination parameter.
        $page   = max( 1, isset( $_GET['pagenum'] ) ? absint( $_GET['pagenum'] ) : 1 );
        $offset = ( $page - 1 ) * 50;

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Read-only paginated admin listing of custom plugin table.
        $rules = $wpdb->get_results(
            $wpdb->prepare(
                'SELECT * FROM %i ORDER BY id DESC LIMIT 50 OFFSET %d',
                $rules_table,
                $offset
            )
        );

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Read-only paginated admin listing of custom plugin table.
        $logs = $wpdb->get_results(
            $wpdb->prepare(
                'SELECT * FROM %i ORDER BY last_seen DESC, id DESC LIMIT 50 OFFSET %d',
                $logs_table,
                $offset
            )
        );

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Admin-only counts for custom plugin tables.
        $count_rules = (int) $wpdb->get_var( $wpdb->prepare( 'SELECT COUNT(*) FROM %i', $rules_table ) );
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Admin-only counts for custom plugin tables.
        $count_logs = (int) $wpdb->get_var( $wpdb->prepare( 'SELECT COUNT(*) FROM %i', $logs_table ) );

        echo '<div class="wrap"><h1>Redirection &amp; 404 Manager</h1>';

        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only admin notice parameter.
        $notice = isset( $_GET['notice'] ) ? sanitize_key( wp_unslash( $_GET['notice'] ) ) : '';

        $messages = array(
            'saved'   => 'Redirect saved.',
            'deleted' => 'Item deleted.',
            'cleared' => '404 log cleared.',
            'invalid' => 'Invalid input. Use a path beginning with / and a valid HTTP(S) destination.',
            'error'   => 'Could not save. The source path may already exist.',
        );

        if ( isset( $messages[ $notice ] ) ) {
            $notice_class = in_array( $notice, array( 'invalid', 'error' ), true ) ? 'notice-error' : 'notice-success';
            echo '<div class="notice ' . esc_attr( $notice_class ) . ' is-dismissible"><p>' . esc_html( $messages[ $notice ] ) . '</p></div>';
        }

        echo '<h2>' . ( $edit ? 'Edit redirect' : 'Add redirect' ) . '</h2>';
        self::form_start( 'save', $edit ? $edit->id : 0 );

        echo '<table class="form-table">';
        echo '<tr><th><label for="roodrar404-source">Source path</label></th><td>';
        echo '<input class="regular-text" id="roodrar404-source" name="source" required maxlength="2048" placeholder="/old-page" value="' . esc_attr( $edit ? $edit->source : $prefill ) . '">';
        echo '<p class="description">Exact path only, starting with /. Case-sensitive; query strings are ignored. Include the site subdirectory, if any.</p></td></tr>';

        echo '<tr><th><label for="roodrar404-target">Destination</label></th><td>';
        echo '<input class="regular-text" id="roodrar404-target" name="target" required maxlength="2048" placeholder="/new-page or https://example.com/" value="' . esc_attr( $edit ? $edit->target : '' ) . '">';
        echo '<p class="description">A root-relative path or an absolute HTTP(S) URL. Incoming query strings are not forwarded.</p></td></tr>';

        echo '<tr><th><label for="roodrar404-code">HTTP status</label></th><td><select id="roodrar404-code" name="status_code">';
        foreach ( array( 301 => '301 – Permanent', 302 => '302 – Temporary', 307 => '307 – Temporary (preserve method)', 308 => '308 – Permanent (preserve method)' ) as $code => $label ) {
            echo '<option value="' . esc_attr( $code ) . '" ' . selected( $edit ? (int) $edit->status_code : 301, $code, false ) . '>' . esc_html( $label ) . '</option>';
        }
        echo '</select></td></tr>';

        echo '<tr><th>Enabled</th><td><label><input type="checkbox" name="enabled" value="1" ' . checked( $edit ? (int) $edit->enabled : 1, 1, false ) . '> Active</label></td></tr>';
        echo '</table>';

        submit_button( $edit ? 'Update redirect' : 'Add redirect' );
        if ( $edit ) {
            echo '<a href="' . esc_url( self::url() ) . '">Cancel editing</a>';
        }
        echo '</form>';

        echo '<h2>Redirects <span class="count">(' . esc_html( $count_rules ) . ')</span></h2>';
        echo '<table class="widefat striped"><thead><tr><th>Source</th><th>Destination</th><th>Status</th><th>Hits</th><th>Last hit (UTC)</th><th>Actions</th></tr></thead><tbody>';

        if ( ! $rules ) {
            echo '<tr><td colspan="6">No redirects on this page.</td></tr>';
        }

        foreach ( $rules as $r ) {
            echo '<tr><td><code>' . esc_html( $r->source ) . '</code></td>';
            echo '<td style="overflow-wrap:anywhere">' . esc_html( $r->target ) . '</td>';
            echo '<td>' . esc_html( $r->status_code ) . ( $r->enabled ? '' : ' (disabled)' ) . '</td>';
            echo '<td>' . esc_html( $r->hits ) . '</td><td>' . esc_html( $r->last_hit ? $r->last_hit : '—' ) . '</td><td>';
            echo '<a href="' . esc_url( self::url( array( 'edit' => $r->id ) ) ) . '">Edit</a> ';
            self::form_start( 'delete_rule', $r->id );
            echo '<button type="submit" class="button-link-delete" onclick="return confirm(\'Delete this redirect?\')">Delete</button></form></td></tr>';
        }

        echo '</tbody></table>';
        echo '<h2>Recent 404 paths <span class="count">(' . esc_html( $count_logs ) . ')</span></h2>';
        echo '<p>Paths only are recorded; query strings, IP addresses and referrers are not stored. Logging is approximate and may be affected by caching. Storage is periodically trimmed to 1,000 paths.</p>';

        self::form_start( 'clear_logs' );
        echo '<button class="button" type="submit" onclick="return confirm(\'Clear all 404 logs?\')">Clear all logs</button></form>
';
        echo '<table class="widefat striped"><thead><tr><th>Path</th><th>Hits</th><th>Last seen (UTC)</th><th>Actions</th></tr></thead><tbody>';

        if ( ! $logs ) {
            echo '<tr><td colspan="4">No 404s on this page.</td></tr>';
        }

        foreach ( $logs as $log ) {
            echo '<tr><td><code>' . esc_html( $log->path ) . '</code></td>';
            echo '<td>' . esc_html( $log->hits ) . '</td><td>' . esc_html( $log->last_seen ) . '</td><td>';
            echo '<a href="' . esc_url( self::url( array( 'source' => $log->path ) ) ) . '#roodrar404-source">Create redirect</a> ';
            self::form_start( 'delete_log', $log->id );
            echo '<button class="button-link-delete" type="submit" onclick="return confirm(\'Delete this log?\')">Delete</button></form></td></tr>';
        }

        echo '</tbody></table>';

        $pages = max( 1, (int) ceil( max( $count_rules, $count_logs ) / 50 ) );
        echo '<p>Page ' . esc_html( $page ) . ' of ' . esc_html( $pages ) . '  ';
        if ( $page > 1 ) {
            echo '<a class="button" href="' . esc_url( self::url( array( 'pagenum' => $page - 1 ) ) ) . '">Previous</a> ';
        }
        if ( $page < $pages ) {
            echo '<a class="button" href="' . esc_url( self::url( array( 'pagenum' => $page + 1 ) ) ) . '">Next</a>';
        }
        echo '</p></div>';
    }
}

register_activation_hook( __FILE__, array( 'Roodra_Redirect404_Manager', 'activate' ) );
add_action( 'admin_menu', array( 'Roodra_Redirect404_Manager', 'menu' ) );
add_action( 'admin_post_roodrar404_action', array( 'Roodra_Redirect404_Manager', 'actions' ) );
add_action( 'template_redirect', array( 'Roodra_Redirect404_Manager', 'redirect' ), 1 );
add_action( 'template_redirect', array( 'Roodra_Redirect404_Manager', 'log_404' ), 999 );
