<?php
/**
 * Uninstall routine for Roodra Redirection & 404 Manager.
 *
 * @package Roodra_Redirection_404_Manager
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

global $wpdb;

$roodrar404_rules_table = $wpdb->prefix . 'roodrar404_rules';
$roodrar404_logs_table  = $wpdb->prefix . 'roodrar404_logs';

// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.SchemaChange, WordPress.DB.DirectDatabaseQuery.NoCaching -- Plugin tables are removed during uninstall.
$wpdb->query( $wpdb->prepare( 'DROP TABLE IF EXISTS %i', $roodrar404_rules_table ) );

// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.SchemaChange, WordPress.DB.DirectDatabaseQuery.NoCaching -- Plugin tables are removed during uninstall.
$wpdb->query( $wpdb->prepare( 'DROP TABLE IF EXISTS %i', $roodrar404_logs_table ) );

delete_option( 'roodrar404_cache_version' );
